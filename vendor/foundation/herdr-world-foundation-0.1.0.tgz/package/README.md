# @herdr-world/foundation

Foundation is the complete generic Herdr browser application, packaged as an npm-compatible
`@herdr-world/foundation` artifact. This repository builds the artifact but does not publish it to
npm yet. It owns the browser root, the real
Spaces/Tabs/Panes shell, bridge profiles and runtime capability services, navigation, generic
settings, terminal ownership and Ghostty renderer integration, notes, uploads, and the desktop/mobile
controls already supported by Herdr Web.

The package exposes one application entry point:

```tsx
import { mountFoundationBrowser } from "@herdr-world/foundation";
import "@herdr-world/foundation/styles.css";

const root = document.getElementById("root");
if (!root) throw new Error("missing root element");

mountFoundationBrowser(root);
```

The public, versioned composition contract is exported from
`@herdr-world/foundation/surfaces`:

```tsx
import {
  FOUNDATION_SURFACE_API_VERSION,
  createProductAssembly,
  defineSurface,
} from "@herdr-world/foundation/surfaces";
import {
  createFoundationApplication,
  foundationConformanceAssembly,
} from "@herdr-world/foundation";

const surface = defineSurface({
  definition: {
    id: "product",
    label: "Product",
    route: "/product",
    semanticIcon: "product",
    requiredBridgeFeatures: ["snapshot"],
  },
  load: async () => import("./compiled-product-surface"),
  createContext: (host) => ({ host }),
  dispose: ({ host }) => host.navigation.goTo("spaces"),
});

const assembly = createProductAssembly({
  surfaceApiVersion: FOUNDATION_SURFACE_API_VERSION,
  // Foundation continues to own and provide Spaces. A product adds to the
  // validated assembly; it does not recreate the Foundation surface.
  surfaces: [...foundationConformanceAssembly.surfaces, surface],
});
const FoundationProductApp = createFoundationApplication(assembly);
```

`defineSurface`, `defineProductSettingsContribution`, and
`createProductAssembly` retain their registration generics behind opaque
runtime storage. The host exposes qualified semantic facts, capabilities,
allow-listed commands, navigation, and managed terminal handles; it does not
expose bridge URLs, WebSockets, renderers, raw fetch, or owner objects.

Foundation validates API version, IDs, routes, and required features before
mounting. Each route and optional product-settings contribution has serialized
load/context/dispose generations, local loading/unavailable/error/retry states,
and Foundation-owned cleanup. The default assembly is the real Spaces-only
application and remains the behavior of `mountFoundationBrowser`.

`FoundationBrowserRoot` is also exported for consumers that already own a React tree. Consumers do
not provide a bridge provider, router, runtime poller, WebSocket URL builder, terminal owner, or
rendering callback. React and React DOM are peer dependencies so the application uses the consumer's
singleton instances.

Foundation asset URLs are available from the documented `foundationAssets` export. Raw packaged
assets, including the PWA manifest and icons, are available under the documented
`@herdr-world/foundation/assets/*` export.

The machine-readable compatibility record is available from
`@herdr-world/foundation/compatibility.json` and is also included at the package root. It records
the Foundation surface API, bridge compatibility, supported Herdr version, and terminal protocol.

This first tranche contains only the generic application. Office, World providers, World settings,
observability adaptation, artwork, installers, and plugin registries are intentionally not part of
this package.
