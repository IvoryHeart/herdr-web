# Foundation candidate provenance

This directory is copied into every candidate bundle. It identifies the
independent downstream relationship and the exact recorded upstream inputs;
it does not assign third-party copyright to Foundation.

- `herdr-web.md` records the Herdr Web-derived generic source boundary.
- `herdr-world-compat.md` records the vendored Herdr Apache-2.0 compatibility slice.
- `components.json` maps distributed component classes to immutable revisions,
  paths, licenses, and required notices.

Generated npm and Cargo dependency inventories and their license metadata live
beside this directory under `inventory/` and `licenses/` in the candidate
bundle.
