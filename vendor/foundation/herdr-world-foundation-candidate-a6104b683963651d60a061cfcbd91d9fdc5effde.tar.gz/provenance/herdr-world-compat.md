# Vendored Herdr compatibility provenance

`vendor/herdr-world-compat/` is a minimal copied compatibility component. It
is not a full Herdr source snapshot and the Foundation build never imports an
external Herdr checkout.

- Source repository: `https://github.com/herdrdev/herdr`
- Audited release: `v0.8.2`
- Exact peeled source commit: `9eb521456ac0d19d3ab3d9d7cea3cca10baa8a4c`
- License: Apache-2.0, preserved in `LICENSE-APACHE-2.0`
- Component name: `herdr-world-compat`

The copied source paths and intentional adaptations are listed in
`docs/vendoring.md`. The bridge requires terminal protocol 20 and rejects
other protocols before serving the browser. No Herdr project endorses this
downstream compatibility component.
