# Herdr Web provenance

Foundation is an independent downstream project. Generic browser and bridge
work was derived in part from the Herdr Web project at:

`https://github.com/kcosr/herdr-web`

The audited Herdr Web comparison/synchronization revision for this Foundation
line is:

`e67537b6bdd99fe489584252ba2f84ea070a3193`

The Foundation repository keeps its own Git history and review boundary. This
record is provenance, not an upstream endorsement or a claim that Herdr Web
maintainers support Foundation artifacts. The received Herdr Web MIT terms
remain applicable to material derived from that project; Foundation additions
retain the repository's recorded MIT scope.
